const express = require('express');
const cookieParser = require('cookie-parser');
const { Pool } = require('pg');
const { exec, execFile } = require('child_process');
const es6Renderer = require('express-es6-template-engine')
const handlebars = require('express-handlebars')
const port = 3000;
const app = express();

app.set('view engine', 'hbs');
app.engine('hbs', handlebars({
  layoutsDir: __dirname + '/views/layouts',
  extname: "hbs"
}))
app.use(express.static('public'))
app.use(cookieParser());
app.use(bodyParser());
app.use(methodOverride('X-HTTP-Method-Override'));
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header("Access-Control-Allow-Methods", "PUT, GET, POST, DELETE, OPTIONS");
  next();
})

var pool = new pg.Pool({
  connectionString: 'postgres://postgres:postgres@'+db+'/postgres'
});

async.retry(
  {times: 1000, interval: 1000},
  function(callback) {
    pool.connect(function(err, client, done) {
      if (err) {
        console.error("Waiting for db");
      }
      callback(err, client);
    });
  },
  function(err, client) {
    if (err) {
      return console.error("Giving up");
    }
    console.log("Connected to db");
    getVotes(client);
  }
);
global.hello_message = "Hello World!"
global.image_url     = ""

app.get('/', = function(req, res){
  res.cookie('username', req.query.username);
  res.render('main', {layout : 'index', hello_message: req.query.hello_message, image: image, image_url: global.image_url});
}

app.get('/user', async (req, res) => {
  const userId = req.query.id;
  const query = "SELECT * FROM users WHERE id = "+userId;
  const [rows] = await pool.query(query);
  res.json(rows);
});

app.get('/ping', (req, res) => {
  exec(`ping -c 4 ${req.query.host}`, (err, stdout) => {
    res.send(stdout);
  });
});

app.listen(port, () => {
 console.log(`Server is running at http://localhost:${port}`);
});
